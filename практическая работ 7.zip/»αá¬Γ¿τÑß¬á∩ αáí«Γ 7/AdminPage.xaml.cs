﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace практическая_работ_7
{
    /// <summary>
    /// Логика взаимодействия для AdminPage.xaml
    /// </summary>
    public partial class AdminPage : Page
    {
        public int CurrentUserRole { get; set; }
        public int age { get; set; }
        public Employee employee = new Employee();
        public List<Employee> employees { get; set; } = new List<Employee>();
        public AdminPage(int userRole )
        {
            InitializeComponent(); 
            CurrentUserRole = userRole;
        
            employees = new List<Employee>();
            EmployeeDG.ItemsSource = Employee.employees;
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            if (EmployeeDG.SelectedItem is Employee selectEmployee)
            {
                employees.Remove(selectEmployee);
                Employee.employees.Remove(selectEmployee);
                EmployeeDG.ItemsSource = null;
                EmployeeDG.ItemsSource = employees;
            }
            else
            {
                MessageBox.Show("Выберите сотрудника для удаления");
            }
        }

        private void SortBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            switch (SortBox.SelectedIndex)
            {
                case 0:
                    employees = employees.OrderBy(emp => emp.LastName).ThenBy(emp => emp.Age).ToList();
                    break;
                case 1:
                    employees = employees.OrderByDescending(emp => emp.LastName).ThenByDescending(emp => emp.Age).ToList();
                    break;
            }
            EmployeeDG.ItemsSource = null;
            EmployeeDG.ItemsSource = employees;
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            if (employees != null && CurrentUserRole >= 0)
            {
                addWindow add = new addWindow(employees.Count, CurrentUserRole);
                add.ShowDialog();

                // проверка на добавление сотрудника
                if (add.employee != null && add.employee.Age >= 18)
                {
                    // Проверка на пустые поля "Имя" и "Фамилия"
                    if (string.IsNullOrWhiteSpace(add.employee.FirstName))
                    {
                        MessageBox.Show("Поле 'Имя' не может быть пустым.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                        return; // Останавливаем дальнейшее выполнение, если ошибка
                    }

                    if (string.IsNullOrWhiteSpace(add.employee.LastName))
                    {
                        MessageBox.Show("Поле 'Фамилия' не может быть пустым.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                        return; // Останавливаем дальнейшее выполнение, если ошибка
                    }

                    if (string.IsNullOrWhiteSpace(add.employee.Position))
                    {
                        MessageBox.Show("Поле 'Должность' не может быть пустым.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                        return; // Останавливаем дальнейшее выполнение, если ошибка
                    }

                    

                    employees.Add(add.employee);
                    employee.addEmployee(add.employee);
                    EmployeeDG.ItemsSource = null;
                    EmployeeDG.ItemsSource = employees;
                }
                else
                {
                    MessageBox.Show("Ошибка при добавлении сотрудника. Проверьте корректность данных.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Ошибка при добавлении сотрудника. Проверьте корректность данных.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            if (EmployeeDG.SelectedItem is Employee selectEmployee)
            {
                addWindow add = new addWindow(selectEmployee);
                add.ShowDialog();
                if (add.employee != null)
                {
                    // проверка возраста сотрудника
                    if (add.employee.Age >= 18)
                    {
                        // Проверка на пустые поля "Имя" и "Фамилия"
                        if (string.IsNullOrWhiteSpace(add.employee.FirstName))
                        {
                            MessageBox.Show("Поле 'Имя' не может быть пустым.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                            return; // Останавливаем дальнейшее выполнение, если ошибка
                        }

                        if (string.IsNullOrWhiteSpace(add.employee.LastName))
                        {
                            MessageBox.Show("Поле 'Фамилия' не может быть пустым.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                            return; // Останавливаем дальнейшее выполнение, если ошибка
                        }

                        if (string.IsNullOrWhiteSpace(add.employee.Position))
                        {
                            MessageBox.Show("Поле 'Должность' не может быть пустым.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                            return; // Останавливаем дальнейшее выполнение, если ошибка
                        }
                        if (EmployeeDG.SelectedIndex >= 0 && EmployeeDG.SelectedIndex < employees.Count)
                        {
                            employees[EmployeeDG.SelectedIndex] = add.employee;
                            Employee.employees[EmployeeDG.SelectedIndex] = add.employee;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Возраст сотрудника должен быть не менее 18 лет.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                }
                
                else
                {
                     MessageBox.Show("Индекс за пределами диапазона. Попробуйте снова выбрать сотрудника.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }

                EmployeeDG.ItemsSource = null;
                EmployeeDG.ItemsSource = employees;
            }
            else
            {
                MessageBox.Show("Выберите сотрудника для редактирования.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
    }
}
